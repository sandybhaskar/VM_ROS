#include<iostream>
#include"message.h"
using namespace std;

void message::printMessage(){
	cout<<"MakeFile Example Sandhya"<<endl;
}
