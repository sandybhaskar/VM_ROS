#include"message.h"
#include<cstdlib>

using namespace std;

int main()
{
	message m;
	m.printMessage();
	return 0;

}
